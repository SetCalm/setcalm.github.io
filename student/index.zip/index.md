---
title: student
date: 2018-11-08 21:58:40
type: student
---

## 硬件

## 嵌入式

### 学前准备

#### 环境配置

### ARM

裸机开发

### Linux

## Windows